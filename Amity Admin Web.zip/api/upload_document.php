<?php
$con = mysqli_connect("localhost", "u843230181_Amity2", "Amitydb123", "u843230181_Amitydb2");

// Check if file and patient name are provided
if (isset($_FILES["document"]["name"]) && isset($_POST["patient_name"])) {
    $patient_name = $_POST["patient_name"];
    $document_name = $_FILES["document"]["name"];
    $document_tmp_name = $_FILES["document"]["tmp_name"];
    $upload_directory = "uploads/";

    // Create the upload directory if it doesn't exist
    if (!is_dir($upload_directory)) {
        mkdir($upload_directory, 0777, true);
    }

    // Move the uploaded file to the server
    $file_path = $upload_directory . basename($document_name);
    if (move_uploaded_file($document_tmp_name, $file_path)) {
        // Insert the file path into the database for the patient
        $sql = "UPDATE patients SET document_path = '$file_path' WHERE patient_name = '$patient_name'";
        if (mysqli_query($con, $sql)) {
            $response = array("success" => "1", "message" => "Document uploaded successfully");
        } else {
            $response = array("success" => "0", "message" => "Failed to associate document with patient");
        }
    } else {
        $response = array("success" => "0", "message" => "Failed to upload document");
    }
} else {
    $response = array("success" => "0", "message" => "Document and patient name are required");
}

header('Content-type: application/json');
echo json_encode($response);

// Close the database connection
mysqli_close($con);
?>
