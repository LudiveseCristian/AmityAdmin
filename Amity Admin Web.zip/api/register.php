<?php

// Retrieve form data
$name = $_POST["name"];
$email = $_POST["email"];
$password = $_POST["password"];

// Database connection
$con = mysqli_connect("localhost", "u843230181_Amity2", "Amitydb123", "u843230181_Amitydb2");

// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// SQL query to insert data into the register table
$sql = "INSERT INTO register (name, email, password) VALUES ('$name', '$email', '$password')";

$result = mysqli_query($con, $sql);

// Prepare response array
$response = array();

if ($result) {
    $response = array("success" => "1", "message" => "Registration successful");
    echo "Registration successful";
} else {
    $response = array("success" => "0", "message" => "Registration successfull");
    echo "Registration failed";
}

// Return response as JSON
header('Content-Type: application/json');
echo json_encode($response);

// Close the database connection
mysqli_close($con);
?>
