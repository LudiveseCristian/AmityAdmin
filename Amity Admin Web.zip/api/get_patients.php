<?php
header('Content-Type: application/json');

$servername = "localhost";
$username = "u843230181_Amity2"; 
$password = "Amitydb123"; 
$dbname = "u843230181_Amitydb2"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Connection failed: " . $conn->connect_error]));
}

$sql = "SELECT id, name, phoneNumber, address, gender, status, birthday, checkup_date AS checkupDate, created_at AS createdAt, updated_at AS updatedAt FROM patients";
$result = $conn->query($sql);

$patients = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $patients[] = $row;
    }
}

echo json_encode(["status" => "success", "data" => $patients]);

$conn->close();
?>
