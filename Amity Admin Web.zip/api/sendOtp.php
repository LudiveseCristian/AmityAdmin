<?php
header('Content-Type: application/json');
require 'vendor/autoload.php';

// Database connection details
$host = "localhost"; 
$dbname = "u843230181_Amitydb2"; 
$username = "u843230181_Amity2"; 
$password = "Amitydb123"; 

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die(json_encode([
        'status' => 'error',
        'message' => 'Connection failed: ' . $e->getMessage()
    ]));
}

// SendGrid initialization
$sendgrid = new \SendGrid('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');

function sendOtp($email, $otp) {
    global $sendgrid;

    $emailContent = new \SendGrid\Mail\Mail();
    $emailContent->setFrom("amitymc.otp@gmail.com", "Amity Medical Clinic"); 
    $emailContent->setSubject("Your OTP Code");
    $emailContent->addTo($email);
    $emailContent->addContent("text/plain", "Your OTP code is: " . $otp);

    try {
        $response = $sendgrid->send($emailContent);
        return [
            'status' => 'success',
            'message' => 'OTP sent successfully.'
        ];
    } catch (Exception $e) {
        return [
            'status' => 'error',
            'message' => 'Caught exception: '. $e->getMessage()
        ];
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? null; // Handle missing email input

    // Check if email is provided
    if (!$email) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Email is required.'
        ]);
        exit;
    }

    // Check if the email exists in the register table
    $stmt = $pdo->prepare("SELECT * FROM register WHERE email = ?");
    $stmt->execute([$email]);
    
    if ($stmt->rowCount() > 0) {
        $otp = rand(100000, 999999); // Generate a random OTP

        // Insert OTP into the otp_verifications table with initial usage count
        $insertStmt = $pdo->prepare("INSERT INTO otp_verifications (user_email, otp_code, usage_count) VALUES (?, ?, 0)");
        $insertStmt->execute([$email, $otp]);

        // Send OTP to the user's email
        $result = sendOtp($email, $otp);
        echo json_encode($result);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Email not found in the database.'
        ]);
    }
}
?>
