<?php
header('Content-Type: application/json');

$host = "localhost"; 
$dbname = "u843230181_Amitydb2"; 
$username = "u843230181_Amity2"; 
$password = "Amitydb123"; 

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Database connection failed: ' . $e->getMessage()
    ]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_email = $_POST['user_email'] ?? null; 
    $otp = $_POST['otp'] ?? null;

    if ($user_email && $otp) {
        $stmt = $pdo->prepare("SELECT * FROM otp_verifications WHERE user_email = ? AND otp_code = ?");
        $stmt->execute([$user_email, $otp]);

        if ($stmt->rowCount() > 0) {
            $otpData = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($otpData['usage_count'] < 5) {
                $updateStmt = $pdo->prepare("UPDATE otp_verifications SET usage_count = usage_count + 1 WHERE user_email = ? AND otp_code = ?");
                $updateStmt->execute([$user_email, $otp]);

                echo json_encode([
                    'status' => 'success',
                    'message' => 'OTP verified successfully. You can now change your password.'
                ]);
            } else {
                echo json_encode([
                    'status' => 'error',
                    'message' => 'OTP usage limit exceeded. Please request a new OTP.'
                ]);
            }
        } else {
            echo json_encode([
                'status' => 'error',
                'message' => 'Invalid OTP.'
            ]);
        }
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Please provide both email and OTP.'
        ]);
    }
}


$stmt->close();
$pdo = null; 
?>
