<?php
$host = "localhost"; 
$dbname = "u843230181_Amitydb2"; 
$username = "u843230181_Amity2"; 
$password = "Amitydb123"; 

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        
        $name = $_POST['name'];
        $address = $_POST['address'];
        $phone = $_POST['phone'];
        $gender = $_POST['gender'];
        $status = $_POST['status'];
        $birthday = $_POST['birthday'];
        $checkup_date = $_POST['checkup_date'];

        $blood_pressure = $_POST['blood_pressure'];
        $pulse_rate = $_POST['pulse_rate'];
        $resp_rate = $_POST['resp_rate'];
        $weight = $_POST['weight'];
        $temperature = $_POST['temperature'];

        $cc = $_POST['cc'];
        $pe = $_POST['pe'];
        $dx = $_POST['dx'];
        $meds = $_POST['meds'];
        $labs = $_POST['labs'];

        $vital_signs = "Blood Pressure: $blood_pressure mmHg, Pulse Rate: $pulse_rate bpm, Resp Rate: $resp_rate breaths/min, 
                        Weight: $weight kg, Temperature: $temperature °C, CC: $cc, PE: $pe, DX: $dx, Meds: $meds, Labs: $labs";

        $year = date('y'); 
        $month = date('m'); 

        $stmt_last_id = $conn->query("SELECT id FROM patients ORDER BY id DESC LIMIT 1");
        $last_row = $stmt_last_id->fetch(PDO::FETCH_ASSOC);

        if ($last_row) {
            $last_id_parts = explode('-', $last_row['id']);
            $last_order_number = (int) (count($last_id_parts) == 2 ? $last_id_parts[1] : 0);
        } else {
            $last_order_number = 0; 
        }

        $new_order_number = $last_order_number + 1;

        $new_id = sprintf("%02d%02d-%05d", $year, $month, $new_order_number);

        $sql = "INSERT INTO patients (id, name, address, phone, gender, status, birthday, vital_signs, checkup_date, created_at, updated_at) 
                VALUES (:id, :name, :address, :phone, :gender, :status, :birthday, :vital_signs, :checkup_date, NOW(), NOW())";

        $stmt = $conn->prepare($sql);

        $stmt->bindParam(':id', $new_id);
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':address', $address);
        $stmt->bindParam(':phone', $phone);
        $stmt->bindParam(':gender', $gender);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':birthday', $birthday);
        $stmt->bindParam(':vital_signs', $vital_signs);
        $stmt->bindParam(':checkup_date', $checkup_date);

        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Patient added successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to add patient']);
        }
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
