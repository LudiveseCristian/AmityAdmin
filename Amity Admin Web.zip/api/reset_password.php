<?php
$host = "localhost";
$dbname = "u843230181_Amitydb2";
$username = "u843230181_Amity2";
$password = "Amitydb123";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => 'Database connection failed: ' . $e->getMessage()]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $new_password = $_POST['new_password'];

    if (!empty($email) && !empty($new_password)) {
        
        $sql = "UPDATE register SET password = :password WHERE email = :email";

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':password', $new_password);
        $stmt->bindParam(':email', $email);

        if ($stmt->execute()) {
            if ($stmt->rowCount() > 0) {
                $response = ['status' => 'success', 'message' => 'Password reset successfully.'];
            } else {
                $response = ['status' => 'error', 'message' => 'No account found with that email.'];
            }
        } else {
            $response = ['status' => 'error', 'message' => 'Failed to reset password. Please try again.'];
        }
    } else {
        $response = ['status' => 'error', 'message' => 'Email and password are required.'];
    }

    echo json_encode($response);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
}

$conn = null;
?>
