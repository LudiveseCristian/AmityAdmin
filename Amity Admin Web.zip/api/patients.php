<?php
header('Content-Type: application/json');

$host = 'localhost';
$db = 'u843230181_Amitydb2';
$user = 'u843230181_Amity2';
$pass = 'Amitydb123';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die(json_encode(array('status' => 'error', 'message' => 'Connection failed: ' . $conn->connect_error)));
}

$search = isset($_GET['query']) ? $conn->real_escape_string($_GET['query']) : '';

$sql = "SELECT * FROM patients WHERE name LIKE '%$search%'";

$result = $conn->query($sql);

$patients = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $patients[] = $row;
    }
}

echo json_encode(array('status' => 'success', 'data' => $patients));

$conn->close();
?>
