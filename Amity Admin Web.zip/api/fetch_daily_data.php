<?php
header('Content-Type: application/json');

// Database configuration
$host = 'localhost';
$db_name = 'u843230181_Amity2'; // Change to your database name
$db_user = 'u843230181_Amitydb2'; // Change to your database user
$db_password = 'Amitydb123'; // Change to your database password

// Create a connection to the database
$conn = new mysqli($host, $db_user, $db_password, $db_name);

// Check connection
if ($conn->connect_error) {
    die(json_encode(['error' => 'Database connection failed: ' . $conn->connect_error]));
}

// SQL query to fetch daily graph data
$query = "SELECT date_column AS xValue, COUNT(*) AS yValue FROM your_table_name GROUP BY date_column ORDER BY date_column"; // Replace with your actual table name and date column

$result = $conn->query($query);

// Prepare an array to hold the data
$data = [];

if ($result->num_rows > 0) {
    // Fetch the data and populate the array
    while ($row = $result->fetch_assoc()) {
        $data[] = [
            'xValue' => strtotime($row['xValue']) * 1000, // Convert to milliseconds
            'yValue' => (int)$row['yValue']
        ];
    }
}

// Return the data as JSON
echo json_encode(['data' => $data]);

// Close the database connection
$conn->close();
?>
