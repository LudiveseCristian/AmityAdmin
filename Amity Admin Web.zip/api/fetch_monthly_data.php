<?php
$con = mysqli_connect("localhost", "u843230181_Amity2", "Amitydb123", "u843230181_Amitydb2");

// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Prepare SQL query to fetch data
$sql = "SELECT * FROM patients";
$result = mysqli_query($con, $sql);

$json_array = array();
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $json_array[] = $row;
    }

    $response = array("success" => "1", "data" => $json_array);
} else {
    $response = array("success" => "0", "message" => "Error fetching data");
}

header('Content-Type: application/json');
echo json_encode($response);

// Close the database connection
mysqli_close($con);
?>
