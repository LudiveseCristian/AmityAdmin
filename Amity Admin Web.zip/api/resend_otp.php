<?php
$servername = "localhost";
$username = "u843230181_Amity2";
$password = "Amitydb123";
$dbname = "u843230181_Amitydb2";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Database connection failed: " . $conn->connect_error]));
}

$email_or_phone = $_POST['email_or_phone'];  // Email or phone input
$new_otp = rand(100000, 999999);  // Generate a 6-digit OTP
$expiration_time = date('Y-m-d H:i:s', strtotime('+10 minutes'));  // OTP expires in 10 minutes

// Check if the user exists in the otp_verifications table
$stmt = $conn->prepare("SELECT * FROM otp_verifications WHERE user_email = ?");
$stmt->bind_param("s", $email_or_phone);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Update the existing record with the new OTP and expiration time
    $updateStmt = $conn->prepare("UPDATE otp_verifications SET otp_code = ?, expiration_time = ?, is_verified = 0 WHERE user_email = ?");
    $updateStmt->bind_param("sss", $new_otp, $expiration_time, $email_or_phone);
    $updateStmt->execute();

    // Send the new OTP via email or phone
    sendOtp($email_or_phone, $new_otp);  // Function to handle sending OTP
    
    echo json_encode(["status" => "success", "message" => "OTP resent successfully"]);
} else {
    echo json_encode(["status" => "error", "message" => "User not found"]);
}

$stmt->close();
$conn->close();

// Function to send OTP via email or phone
function sendOtp($email_or_phone, $otp) {
    // You can implement sending logic here, depending on whether it's an email or phone number
    if (filter_var($email_or_phone, FILTER_VALIDATE_EMAIL)) {
        // Send OTP via email using SendGrid, PHPMailer, etc.
        // (See previous implementation for email-based OTP sending)
        sendOtpByEmail($email_or_phone, $otp);
    } else {
        // Send OTP via SMS (e.g., using Twilio or any other SMS gateway)
        sendOtpByPhone($email_or_phone, $otp);
    }
}

function sendOtpByEmail($email, $otp) {
    // Your existing SendGrid email OTP logic here
}

function sendOtpByPhone($phone, $otp) {
    // SMS sending logic here (e.g., using Twilio or similar service)
}
?>
