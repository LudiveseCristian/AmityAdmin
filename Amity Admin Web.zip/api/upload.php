<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_FILES['file']['name'])) {
        $target_dir = "uploads/"; // Folder to save the uploaded image

        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true); // Create the folder if it doesn't exist
        }

        $file_name = basename($_FILES["file"]["name"]);
        $file_name = preg_replace("/[^a-zA-Z0-9\._-]/", "_", $file_name); // Sanitize file name
        $target_file = $target_dir . $file_name;

        // Check file size (limit to 2MB for example)
        if ($_FILES["file"]["size"] > 2097152) {
            echo json_encode(["status" => "error", "message" => "File size exceeds 2MB limit"]);
            exit;
        }

        // Check if the file is an image
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        $check = getimagesize($_FILES["file"]["tmp_name"]);
        
        if ($check !== false) {
            // Validate file type (optional, allow only specific image types)
            $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
            if (!in_array($imageFileType, $allowedTypes)) {
                echo json_encode(["status" => "error", "message" => "Only JPG, JPEG, PNG & GIF files are allowed"]);
                exit;
            }

            if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
                echo json_encode(["status" => "success", "message" => "Image uploaded successfully"]);
            } else {
                echo json_encode(["status" => "error", "message" => "Failed to upload image. Please try again."]);
            }
        } else {
            echo json_encode(["status" => "error", "message" => "File is not an image"]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "No file uploaded"]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request method"]);
}
?>
