<?php
// Database connection
$servername = "localhost";
$username = "u843230181_Amity2";
$password = "Amitydb123";
$dbname = "u843230181_Amitydb2";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(array("success" => "0", "message" => "Database connection failed.")));
}

// Get POST input
$name = $_POST['name'] ?? ''; // Use null coalescing to avoid undefined index
$password = $_POST['password'] ?? '';

// Validate inputs
if (empty($name) || empty($password)) {
    echo json_encode(array("success" => "0", "message" => "Please provide username and password."));
    exit;
}

// Check for name and password in the database
$sql = "SELECT * FROM register WHERE name = ? AND password = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $name, $password);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Fetch user details
    $user = $result->fetch_assoc();
    echo json_encode(array(
        "success" => "1",
        "message" => "Login successful.",
        "userDetailObject" => array( // Change to match your LoginResponseModel
            "name" => $user['name'], 
            "password" => $user['password']
        )
    ));
} else {
    echo json_encode(array("success" => "0", "message" => "Invalid username or password."));
}

$stmt->close();
$conn->close();
?>
