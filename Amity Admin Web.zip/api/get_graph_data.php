<?php
$con = mysqli_connect("localhost", "u843230181_Amity2", "Amitydb123", "u843230181_Amitydb2");

// Function to retrieve the count of new patients for a given period
function getPatientCount($con, $interval) {
    $sql = "SELECT COUNT(*) as patient_count FROM patients WHERE checkup_date >= DATE_SUB(CURDATE(), INTERVAL $interval)";
    $result = mysqli_query($con, $sql);
    $row = mysqli_fetch_assoc($result);
    return $row['patient_count'];
}

$daily_count = getPatientCount($con, "1 DAY");
$weekly_count = getPatientCount($con, "1 WEEK");
$monthly_count = getPatientCount($con, "1 MONTH");

$response = array(
    "success" => "1",
    "data" => array(
        "daily" => $daily_count,
        "weekly" => $weekly_count,
        "monthly" => $monthly_count
    )
);

header('Content-type: application/json');
echo json_encode($response);

// Close the database connection
mysqli_close($con);
?>
