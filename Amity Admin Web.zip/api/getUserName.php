<?php
// connection.php
$servername = "localhost";
$username = "u843230181_Amity2";
$password = "Amitydb123";
$dbname = "u843230181_Amitydb2";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch user name based on email
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $email = $_GET['email'];

    $sql = "SELECT name FROM register WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->bind_result($name);
    $stmt->fetch();

    if ($name) {
        echo $name; // Return the name
    } else {
        echo "Not found"; // Handle case when no user is found
    }

    $stmt->close();
}

$conn->close();
?>
