
<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: Login.php"); // Redirect to the login page if not authenticated
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Dashboard</title>
    <link rel="stylesheet" href="CSS/Dashboard.css"/>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet"/>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="d-flex">
    <!-- Sidebar -->
    <nav id="sidebar" class="bg-light border-right">
        <div class="sidebar-header p-3">
            <h4>Dashboard</h4>
        </div>
        <ul class="list-unstyled components">
            <li>
                <a href="MedicalRecords.html"><i class="fas fa-file-medical"></i> Medical Records</a>
            </li>
            <li>
                <a href="Staff.html"><i class="fas fa-users"></i> Staff</a>
            </li>
            <li>
                <a href="#settingsSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                    <i class="fas fa-cog"></i> Settings
                </a>
                <ul class="collapse list-unstyled" id="settingsSubmenu">
                    <li>
                        <a href="ChangeP.html"><i class="fas fa-key"></i> Change Password</a>
                    </li>
                    <li>
                        <a href="LogOut.html"><i class="fas fa-power-off"></i> Log Out</a>
                    </li>
                </ul>
            </li>
        </ul>
    </nav>

    <!-- Main Content -->
    <div class="container-fluid p-4">
        <div class="header">
            <a class="button" href="ChangeP.html">Change Password</a>
            <a class="button" href="Login.html"><i class="fas fa-power-off"></i></a>
        </div>
        <div class="grid">
            <div class="card">
                <div class="button-row">
                    <a class="button-p" id="updateChart">This day</a>
                    <input type="date" class="date-selector" id="dateSelector">
                </div>
                <canvas id="myChart"></canvas>
            </div>

            <div class="recent-visits-card">
                <div class="recent-visits-header">
                    <div class="header-content">
                        <h2>Recent Visits</h2>
                        <a class="small-button" href="MedicalRecords.html" id="viewMoreButton">View More</a>
                    </div>
                </div>
                <br>
                <div class="recent-visits">
                    <!-- Repeat visit items -->
                </div>
            </div>

            <div class="card schedule">
                <h2>Schedule</h2>
                <div class="schedule-items">
                    <!-- Repeat schedule items -->
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
<div class="trademark">2024 Amity Medical Clinic. All Rights Reserved.</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
<script src="JS/Dashboard.js"></script>
</body>
</html>
